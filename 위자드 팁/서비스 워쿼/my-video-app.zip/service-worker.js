const CACHE_NAME = 'yonVideo';

self.addEventListener('fetch', (event) => {
  const { request } = event;

  if (request.url.endsWith('.mp4')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cachedResponse = await cache.match(request);
        if (cachedResponse) {
          return cachedResponse;
        } else {
          // Range 헤더 없이 새 요청 생성
          const cleanRequest = new Request(request.url, {
            method: 'GET',
            headers: new Headers(), // 빈 헤더로 Range 제거
          });

          const networkResponse = await fetch(cleanRequest);

          // 206이 아닌 경우에만 캐시
          if (networkResponse.status === 200) {
            cache.put(request, networkResponse.clone());
          }

          return networkResponse;
        }
      })
    );
  }
});